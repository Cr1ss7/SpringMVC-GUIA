create
    definer = root@localhost procedure sp_obtenerGenero(IN _id_genero int) no sql
SELECT *  FROM generos WHERE id_genero = _id_genero;

