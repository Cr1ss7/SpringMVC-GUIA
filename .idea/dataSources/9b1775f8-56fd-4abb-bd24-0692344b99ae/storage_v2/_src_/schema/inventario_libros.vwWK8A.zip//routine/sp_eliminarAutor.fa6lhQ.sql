create
    definer = root@localhost procedure sp_eliminarAutor(IN _codigo_autor varchar(6)) no sql
DELETE FROM autores WHERE codigo_autor = _codigo_autor;

