create
    definer = root@localhost procedure sp_listarGeneros() no sql
SELECT * FROM generos;

