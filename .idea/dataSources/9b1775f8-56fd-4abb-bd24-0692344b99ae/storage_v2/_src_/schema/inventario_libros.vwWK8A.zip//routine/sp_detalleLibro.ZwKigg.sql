create
    definer = root@localhost procedure sp_detalleLibro(IN _codigo_libro varchar(9)) no sql
SELECT l.codigo_libro, l.nombre_libro, l.existencias,l.precio,g.nombre_genero, a.nombre_autor,e.nombre_editorial, l.descripcion FROM libros l INNER JOIN generos g on l.id_genero= g.id_genero INNER JOIN autores a on l.codigo_autor = a.codigo_autor INNER JOIN editoriales e ON l.codigo_editorial= e.codigo_editorial WHERE l.codigo_libro = _codigo_libro;

