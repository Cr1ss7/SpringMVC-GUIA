create
    definer = root@localhost procedure sp_obtenerLibro(IN _codigo_libro varchar(9)) no sql
SELECT * FROM libros WHERE codigo_libro = _codigo_libro;

