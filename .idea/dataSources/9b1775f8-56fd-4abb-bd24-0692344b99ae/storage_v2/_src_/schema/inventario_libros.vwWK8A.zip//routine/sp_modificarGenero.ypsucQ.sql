create
    definer = root@localhost procedure sp_modificarGenero(IN _nombre_genero varchar(40), IN _descripcion varchar(100),
                                                          IN _id_genero int) no sql
UPDATE generos SET nombre_genero = _nombre_genero, descripcion = _descripcion WHERE id_genero = _id_genero;

