create
    definer = root@localhost procedure sp_insertarLibro(IN _codigo_libro varchar(9), IN _nombre_libro varchar(50),
                                                        IN _existencias int, IN _precio decimal(10, 2),
                                                        IN _codigo_autor varchar(6), IN _codigo_editorial varchar(6),
                                                        IN _id_genero int, IN _descripcion text) no sql
INSERT INTO libros VALUES(_codigo_libro,_nombre_libro,_existencias,_precio,_codigo_autor,_codigo_editorial,_id_genero,_descripcion);

