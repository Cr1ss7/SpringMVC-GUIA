create
    definer = root@localhost procedure sp_insertarAutor(IN _codigo_autor varchar(6), IN _nombre_autor varchar(50),
                                                        IN _nacionalidad varchar(50)) no sql
INSERT INTO autores
VALUES(_codigo_autor, _nombre_autor, _nacionalidad);

