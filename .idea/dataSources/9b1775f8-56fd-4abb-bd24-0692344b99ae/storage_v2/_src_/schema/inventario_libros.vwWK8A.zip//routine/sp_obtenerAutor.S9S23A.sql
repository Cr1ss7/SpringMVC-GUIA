create
    definer = root@localhost procedure sp_obtenerAutor(IN _codigo_autor varchar(6)) no sql
SELECT * FROM autores WHERE codigo_autor = _codigo_autor;

