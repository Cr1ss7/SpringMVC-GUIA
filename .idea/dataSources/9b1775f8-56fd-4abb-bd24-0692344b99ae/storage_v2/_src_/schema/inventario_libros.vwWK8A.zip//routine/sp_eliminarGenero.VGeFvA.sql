create
    definer = root@localhost procedure sp_eliminarGenero(IN _id_genero int) no sql
DELETE FROM generos WHERE id_genero = _id_genero;

