create
    definer = root@localhost procedure sp_modificarLibro(IN _codigo_libro varchar(9), IN _nombre_libro varchar(50),
                                                         IN _existencias int, IN _precio decimal(10, 2),
                                                         IN _codigo_autor varchar(6), IN _codigo_editorial varchar(6),
                                                         IN _id_genero int, IN _descripcion text) no sql
UPDATE libros l SET  l.nombre_libro=_nombre_libro,l.existencias=_existencias,l.precio=_precio,l.codigo_autor=_codigo_autor,l.codigo_editorial=_codigo_editorial,l.id_genero=_id_genero,l.descripcion=_descripcion WHERE l.codigo_libro = _codigo_libro;

