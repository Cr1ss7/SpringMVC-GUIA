create
    definer = root@localhost procedure sp_modificarAutor(IN _nombre_autor varchar(50), IN _nacionalidad varchar(50),
                                                         IN _codigo_autor varchar(6)) no sql
UPDATE autores SET nombre_autor = _nombre_autor, nacionalidad = _nacionalidad WHERE codigo_autor = _codigo_autor;

