create
    definer = root@localhost procedure sp_listarAutores() no sql
SELECT * FROM autores ORDER BY nombre_autor;

