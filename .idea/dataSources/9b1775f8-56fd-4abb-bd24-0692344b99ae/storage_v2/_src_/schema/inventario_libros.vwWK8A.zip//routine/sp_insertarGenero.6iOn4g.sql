create
    definer = root@localhost procedure sp_insertarGenero(IN _nombre_genero varchar(40), IN _descripcion varchar(100))
    no sql
INSERT INTO generos(nombre_genero, descripcion)  VALUES(_nombre_genero,_descripcion);

